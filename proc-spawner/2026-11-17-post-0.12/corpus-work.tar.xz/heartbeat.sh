#!/bin/bash
while :; do echo "$(date -u +%FT%TZ) $(cut -d' ' -f1 /proc/uptime)" >> /home/user/proc-spawner/corpus-work/heartbeat.txt; sleep 30; done

#!/bin/bash
# watch.sh DEADLINE_S: silent until something needs attention
deadline=${1:-7000}; L=/home/user/proc-spawner/corpus-work/all.log
up0=$(cut -d' ' -f1 /proc/uptime | cut -d. -f1); last=$(date +%s); why=
while :; do
  sleep 30
  now=$(date +%s); up=$(cut -d' ' -f1 /proc/uptime | cut -d. -f1)
  [ $((now - last)) -gt 90 ] && { why="gap: no check for $((now - last)) s"; break; }
  [ "$up" -lt "$up0" ] && { why="restart"; break; }
  last=$now
  grep -q '^END ' $L && { why="the run ended"; break; }
  pgrep -f 'make corpus-all' > /dev/null || { why="the run is gone"; break; }
  [ $SECONDS -gt $deadline ] && { why="deadline"; break; }
done
echo "watch: $why"; grep -E '^(make|END|Error)|\*\*\*' $L | tail -3; tail -2 $L | cut -c1-200; uptime

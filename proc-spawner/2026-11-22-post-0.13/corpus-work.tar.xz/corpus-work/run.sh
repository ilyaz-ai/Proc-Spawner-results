#!/bin/bash
# The full corpus run on the branch corpus-run-2026-11-22 (Linux, the spawn primitive as built: posix_spawn).
# Restartable: run it again without corpus-clean; make skips what it has, the runs skip the samples done.
cd /home/user/proc-spawner || exit 1
echo "start $(date -u +%FT%TZ) commit $(git rev-parse --short HEAD) uptime $(cut -d' ' -f1 /proc/uptime)"
make corpus-all OLDSCAN=/home/user/corpus-run/oldscan/large-scan.jsonl SCCACHE=/home/user/corpus-run/oldscan/sc-cache.jsonl
rc=$?
echo "ALL DONE rc=$rc $(date -u +%FT%TZ)"
